<?php
/*
Plugin Name: WP Mobile Stripe API (Independent, cURL only)
Description: Adds REST endpoint /wp-json/stripe/v1/create-payment-intent for mobile apps using only cURL calls (no Stripe SDK).
Version: 2.3
Author: Your Name
*/

if (!defined('ABSPATH')) exit;

// Stripe Secret Key (TEST mode – don’t use in production)
$WPMS_STRIPE_SECRET_KEY = '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';

/**
 * Add CORS headers for mobile app
 */
add_action('rest_api_init', function () {
    header('Access-Control-Allow-Origin: *'); // Change to your domain in production
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Mobile-Secret');
});

/**
 * Register the REST endpoint
 */
add_action('rest_api_init', function () {
    register_rest_route('stripe/v1', '/create-payment-intent', array(
        'methods'  => 'POST',
        'callback' => 'wpms_create_payment_intent',
        'permission_callback' => function ($request) {
            $required_header = 'my_app_secret_123';
            $header = $request->get_header('x-mobile-secret');
            return $header === $required_header;
        },
    ));
});

/**
 * Helper: Create Stripe Customer using cURL
 */
function wpms_create_stripe_customer($secret_key) {
    $ch = curl_init('https://api.stripe.com/v1/customers');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, $secret_key . ':');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'description' => 'Customer created via WP Mobile Stripe API plugin',
    ]));
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code >= 200 && $code < 300) {
        $data = json_decode($response, true);
        return $data['id'] ?? null;
    }
    return null;
}

/**
 * Helper: Create Ephemeral Key using cURL
 */
function wpms_create_ephemeral_key($secret_key, $customer_id) {
    $ch = curl_init('https://api.stripe.com/v1/ephemeral_keys');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, $secret_key . ':');
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Stripe-Version: 2023-10-16']);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'customer' => $customer_id,
    ]));
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code >= 200 && $code < 300) {
        $data = json_decode($response, true);
        return $data['secret'] ?? null;
    }
    return null;
}

/**
 * Helper: Create PaymentIntent using cURL
 */
function wpms_create_payment_intent_curl($secret_key, $amount, $currency, $customer_id, $order_id) {
    $ch = curl_init('https://api.stripe.com/v1/payment_intents');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_USERPWD, $secret_key . ':');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'amount'               => $amount,
        'currency'             => $currency,
        'customer'             => $customer_id,
        'metadata[order_id]'   => $order_id,
    ]));
    $response = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($code >= 200 && $code < 300) {
        return json_decode($response, true);
    }
    return null;
}

/**
 * PaymentIntent creation handler
 */
function wpms_create_payment_intent(WP_REST_Request $request) {
    global $WPMS_STRIPE_SECRET_KEY;

    $amount   = intval($request->get_param('amount'));
    $currency = sanitize_text_field($request->get_param('currency') ?: 'usd');
    $order_id = sanitize_text_field($request->get_param('order_id') ?: '');

    if ($amount <= 0) {
        return new WP_Error('invalid_amount', 'Invalid amount (must be cents, e.g. 1000 = $10)', array('status' => 400));
    }
    if (empty($order_id)) {
        return new WP_Error('invalid_order_id', 'Order ID is required', array('status' => 400));
    }

    try {
        // 1. Create Customer
        $customer_id = wpms_create_stripe_customer($WPMS_STRIPE_SECRET_KEY);
        if (!$customer_id) {
            return new WP_Error('stripe_customer_error', 'Failed to create Stripe customer', array('status' => 500));
        }

        // 2. Create Ephemeral Key
        $ephemeral_key = wpms_create_ephemeral_key($WPMS_STRIPE_SECRET_KEY, $customer_id);
        if (!$ephemeral_key) {
            return new WP_Error('stripe_ephemeral_key_error', 'Failed to create ephemeral key', array('status' => 500));
        }

        // 3. Create PaymentIntent
        $payment_intent = wpms_create_payment_intent_curl($WPMS_STRIPE_SECRET_KEY, $amount, $currency, $customer_id, $order_id);
        if (!$payment_intent || empty($payment_intent['client_secret']) || empty($payment_intent['id'])) {
            return new WP_Error('stripe_payment_intent_error', 'Failed to create payment intent', array('status' => 500));
        }

        return rest_ensure_response([
            'clientSecret' => $payment_intent['client_secret'],
            'id'           => $payment_intent['id'],
            'order_id'     => $order_id,
            'customer'     => $customer_id,
            'ephemeralKey' => $ephemeral_key,
        ]);

    } catch (Exception $e) {
        return new WP_Error('stripe_exception', $e->getMessage(), array('status' => 500));
    }
}

/**
 * Handle CORS preflight
 */
add_action('rest_api_init', function () {
    register_rest_route('stripe/v1', '/create-payment-intent', array(
        array(
            'methods'  => 'OPTIONS',
            'callback' => function () {
                header('Access-Control-Allow-Origin: *');
                header('Access-Control-Allow-Methods: POST, OPTIONS');
                header('Access-Control-Allow-Headers: Content-Type, X-Mobile-Secret');
                return rest_ensure_response(null);
            },
            'permission_callback' => '__return_true',
        )
    ));
});
